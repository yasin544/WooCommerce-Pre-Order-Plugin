<?php
/**
 * Plugin Name: WooCommerce Pre-Order with Upfront Fee
 * Description: Adds a pre-order feature with an upfront fee and availability date in WooCommerce.
 * Version: 1.1
 * Author: Your Name
 * License: GPL2
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Add Pre-Order Fields for Simple & Variable Products
add_action('woocommerce_product_options_general_product_data', function() {
    woocommerce_wp_text_input(array(
        'id' => 'preorder_availability_date',
        'label' => __('Pre-Order Availability Date', 'woocommerce'),
        'type' => 'date',
        'desc_tip' => true,
        'description' => __('Set the date when this product will be available.', 'woocommerce'),
    ));
    
    woocommerce_wp_text_input(array(
        'id' => 'preorder_upfront_fee',
        'label' => __('Upfront Fee', 'woocommerce'),
        'type' => 'number',
        'custom_attributes' => array('step' => '0.01', 'min' => '0'),
        'desc_tip' => true,
        'description' => __('Amount to be charged upfront for the pre-order.', 'woocommerce'),
    ));
});

// Add Pre-Order Fields for Variations
add_action('woocommerce_variation_options_pricing', function($loop, $variation_data, $variation) {
    woocommerce_wp_text_input(array(
        'id' => "preorder_availability_date_{$variation}",
        'name' => "preorder_availability_date[{$variation}]",
        'label' => __('Pre-Order Availability Date', 'woocommerce'),
        'type' => 'date',
        'value' => get_post_meta($variation, 'preorder_availability_date', true),
    ));
    
    woocommerce_wp_text_input(array(
        'id' => "preorder_upfront_fee_{$variation}",
        'name' => "preorder_upfront_fee[{$variation}]",
        'label' => __('Upfront Fee', 'woocommerce'),
        'type' => 'number',
        'custom_attributes' => array('step' => '0.01', 'min' => '0'),
        'value' => get_post_meta($variation, 'preorder_upfront_fee', true),
    ));
}, 10, 3);

// Save Pre-Order Fields
add_action('woocommerce_process_product_meta', function($post_id) {
    if (isset($_POST['preorder_availability_date'])) {
        update_post_meta($post_id, 'preorder_availability_date', sanitize_text_field($_POST['preorder_availability_date']));
    }
    if (isset($_POST['preorder_upfront_fee'])) {
        update_post_meta($post_id, 'preorder_upfront_fee', sanitize_text_field($_POST['preorder_upfront_fee']));
    }
});

add_action('woocommerce_save_product_variation', function($variation_id, $loop) {
    if (isset($_POST['preorder_availability_date'][$variation_id])) {
        update_post_meta($variation_id, 'preorder_availability_date', sanitize_text_field($_POST['preorder_availability_date'][$variation_id]));
    }
    if (isset($_POST['preorder_upfront_fee'][$variation_id])) {
        update_post_meta($variation_id, 'preorder_upfront_fee', sanitize_text_field($_POST['preorder_upfront_fee'][$variation_id]));
    }
}, 10, 2);


// Display Pre-Order Fee in Cart & Checkout
add_filter('woocommerce_cart_item_price', function($price, $cart_item, $cart_item_key) {
    if (!empty($cart_item['preorder_upfront_fee'])) {
        $upfront_fee = wc_price($cart_item['preorder_upfront_fee']);
        $price .= "<br><small><strong>Upfront Fee:</strong> {$upfront_fee}</small>";
    }
    return $price;
}, 10, 3);


// Modify Product Price at Checkout to Charge Only Upfront Fee
add_action('woocommerce_before_calculate_totals', function($cart) {
    if (is_admin() && !defined('DOING_AJAX')) return;

    foreach ($cart->get_cart() as $cart_item) {
        $product_id = $cart_item['product_id'];
        $upfront_fee = get_post_meta($product_id, 'preorder_upfront_fee', true);
        
        if (!empty($upfront_fee) && $upfront_fee > 0) {
            $cart_item['data']->set_price($upfront_fee);
        }
    }
});



// Display Pre-Order Message on Product Page
add_action('woocommerce_single_product_summary', function() {
    global $product;
    
    if ($product->is_type('variable')) {
        echo "<div class='preorder-info'><p>Select a variation to see pre-order details.</p></div>";
    } else {
        $availability_date = get_post_meta($product->get_id(), 'preorder_availability_date', true);
        $upfront_fee = get_post_meta($product->get_id(), 'preorder_upfront_fee', true);
    
        if (!empty($availability_date) || !empty($upfront_fee)) {
            echo "<div class='preorder-info'>";
            if (!empty($availability_date)) {
                echo "<p><strong>Pre-Order Available Until:</strong> $availability_date</p>";
            }
            if (!empty($upfront_fee)) {
                echo "<p><strong>Upfront Fee:</strong> " . wc_price($upfront_fee) . "</p>";
            }
            echo "</div>";
        }
    }
}, 25);

// Adjust Cart Price for Pre-Orders
add_action('woocommerce_before_calculate_totals', function($cart) {
    if (is_admin() && !defined('DOING_AJAX')) return;
    
    foreach ($cart->get_cart() as $cart_item) {
        $product_id = $cart_item['product_id'];
        $variation_id = isset($cart_item['variation_id']) ? $cart_item['variation_id'] : '';
        $upfront_fee = $variation_id ? get_post_meta($variation_id, 'preorder_upfront_fee', true) : get_post_meta($product_id, 'preorder_upfront_fee', true);
        
        if (!empty($upfront_fee) && $upfront_fee > 0) {
            $cart_item['data']->set_price($upfront_fee);
        }
    }
});

// Ensure Variations Are Visible on the Product Page
add_filter('woocommerce_available_variation', function($variation_data, $product, $variation) {
    $availability_date = get_post_meta($variation->get_id(), 'preorder_availability_date', true);
    $upfront_fee = get_post_meta($variation->get_id(), 'preorder_upfront_fee', true);
    
    if (!empty($availability_date) || !empty($upfront_fee)) {
        $variation_data['variation_description'] .= "<p><strong>Pre-Order Available Until:</strong> $availability_date</p>";
        $variation_data['variation_description'] .= "<p><strong>Upfront Fee:</strong> " . wc_price($upfront_fee) . "</p>";
    }
    return $variation_data;
}, 10, 3);



// Shortcode to Display Pre-Order Message with Availability Date
function preorder_message_shortcode() {
    global $product;

    if (!is_a($product, 'WC_Product')) {
        return ''; // Exit if not a product
    }

    $availability_date = get_post_meta($product->get_id(), 'preorder_availability_date', true);
    $upfront_fee = get_post_meta($product->get_id(), 'preorder_upfront_fee', true);

    if (empty($availability_date) && empty($upfront_fee)) {
        return ''; // Exit if no pre-order data exists
    }

    ob_start(); // Start output buffering

    echo "<div class='preorder-message'>";
    
    if (!empty($availability_date)) {
        //echo "<p style='color:red; font-weight:bold;'>Available for Pre-Order</p>";
        echo "<p style='color:blue; font-weight:bold;'>Expected Availability Date: <strong>{$availability_date}</strong></p>";
    }
    
    if (!empty($upfront_fee)) {
        echo "<p><strong>Pre-Order Upfront Fee: </strong> " . wc_price($upfront_fee) . "</p>";
    }

    echo "</div>";

    return ob_get_clean(); // Return buffered output
}
add_shortcode('preorder_message', 'preorder_message_shortcode');



// Show Pre-Order Availability Date on Archive Pages
add_action('woocommerce_after_shop_loop_item_title', function() {
    global $product;
    $availability_date = get_post_meta($product->get_id(), 'preorder_availability_date', true);
    
    if (!empty($availability_date)) {
        echo "<p style='color:red; font-weight:bold;'>Pre-Order Available</p>";
        echo "<p style='color:blue; font-weight:bold;'>Expected Date: <strong>{$availability_date}</strong></p>";
    }
}, 15);


// Show on Checkout Page
add_filter('woocommerce_get_item_data', function($item_data, $cart_item) {
    if (!empty($cart_item['preorder_availability_date'])) {
        $item_data[] = array(
            'name' => __('Pre-Order Availability Date', 'woocommerce'),
            'value' => $cart_item['preorder_availability_date'],
        );
    }
    return $item_data;
}, 10, 2);


// Send Email to Customers After Pre-Order
add_action('woocommerce_thankyou', function($order_id) {
    $order = wc_get_order($order_id);
    foreach ($order->get_items() as $item) {
        $product_id = $item->get_product_id();
        $availability_date = get_post_meta($product_id, 'preorder_availability_date', true);
        
        if (!empty($availability_date)) {
            $email_subject = "Your Pre-Order Confirmation";
            $email_message = "Thank you for pre-ordering! Your product will be available on: {$availability_date}. We will notify you when it is ready for full payment.";
            
            wp_mail($order->get_billing_email(), $email_subject, $email_message);
        }
    }
});


// Remove "Out of Stock" Text for Pre-Order Products
add_filter('woocommerce_get_availability_text', function($availability, $product) {
    if (!empty(get_post_meta($product->get_id(), 'preorder_availability_date', true))) {
        return "<span style='color: green; font-weight: bold;'>Available for Pre-Order</span>";
    }
    return $availability;
}, 10, 2);



// Force "Add to Cart" Button to Show for Pre-Order Products
add_filter('woocommerce_product_add_to_cart_text', function($text, $product) {
    if (!empty(get_post_meta($product->get_id(), 'preorder_availability_date', true))) {
        return __('Pre-Order Now', 'woocommerce'); // Change button text
    }
    return $text;
}, 10, 2);

add_filter('woocommerce_product_is_purchasable', function($purchasable, $product) {
    if (!empty(get_post_meta($product->get_id(), 'preorder_availability_date', true))) {
        return true; // Force the product to be purchasable
    }
    return $purchasable;
}, 10, 2);


// Ensure Quantity Field is Visible for Pre-Orders
add_filter('woocommerce_is_sold_individually', function($sold_individually, $product) {
    if (!empty(get_post_meta($product->get_id(), 'preorder_availability_date', true))) {
        return false; // Allow multiple quantities
    }
    return $sold_individually;
}, 10, 2);

add_filter('woocommerce_quantity_input_args', function($args, $product) {
    if (!empty(get_post_meta($product->get_id(), 'preorder_availability_date', true))) {
        $args['min_value'] = 1; // Ensure minimum is at least 1
        $args['max_value'] = 10; // Adjust as needed
        $args['input_value'] = 1; // Default quantity
    }
    return $args;
}, 10, 2);



// Force Pre-Order Products to Always Show as "In Stock"
add_filter('woocommerce_product_is_in_stock', function($stock_status, $product) {
    if (!empty(get_post_meta($product->get_id(), 'preorder_availability_date', true))) {
        return true; // Force in-stock status
    }
    return $stock_status;
}, 10, 2);


// Allow Pre-Order Products to Be Added to Cart
add_filter('woocommerce_variation_is_purchasable', function($purchasable, $product) {
    if (!empty(get_post_meta($product->get_id(), 'preorder_availability_date', true))) {
        return true;
    }
    return $purchasable;
}, 10, 2);




// Show Pre-Order Remaining Balance Correctly on Checkout Page
add_filter('woocommerce_get_item_data', function($item_data, $cart_item) {
    if (!empty($cart_item['preorder_upfront_fee'])) {
        $total_price = wc_price($cart_item['data']->get_regular_price());
        $upfront_fee = wc_price($cart_item['preorder_upfront_fee']);
        $remaining_balance = wc_price($cart_item['data']->get_regular_price() - $cart_item['preorder_upfront_fee']);

        $item_data[] = array(
            'name' => __('Total Price', 'woocommerce'),
            'value' => $total_price
        );
        $item_data[] = array(
            'name' => __('Upfront Fee (Paid Now)', 'woocommerce'),
            'value' => $upfront_fee
        );
        $item_data[] = array(
            'name' => __('Remaining Balance (Due on Availability)', 'woocommerce'),
            'value' => $remaining_balance
        );
    }
    return $item_data;
}, 10, 2);


add_filter('woocommerce_add_cart_item_data', function ($cart_item_data, $product_id, $variation_id) {
    // Retrieve pre-order metadata from product
    $availability_date = get_post_meta($product_id, 'preorder_availability_date', true);
    $upfront_fee = get_post_meta($product_id, 'preorder_upfront_fee', true);

    if (!empty($availability_date)) {
        $cart_item_data['preorder_availability_date'] = $availability_date;
    }

    if (!empty($upfront_fee)) {
        $cart_item_data['preorder_upfront_fee'] = $upfront_fee;
    }

    // Ensure a unique cart item key to prevent merging
    $cart_item_data['unique_key'] = md5(microtime().rand());

    return $cart_item_data;
}, 10, 3);




add_action('woocommerce_checkout_create_order_line_item', function ($item, $cart_item_key, $values, $order) {
    if (!empty($values['preorder_availability_date'])) {
        $item->add_meta_data(__('Pre-Order Availability Date', 'woocommerce'), $values['preorder_availability_date'], true);
    }

    if (!empty($values['preorder_upfront_fee'])) {
        $item->add_meta_data(__('Pre-Order Upfront Fee', 'woocommerce'), wc_price($values['preorder_upfront_fee']), true);
    }
}, 10, 4);



// Redirect Pre-Order Button Click to Product Detail Page
add_filter('woocommerce_loop_add_to_cart_link', function($button, $product) {
    if (!empty(get_post_meta($product->get_id(), 'preorder_availability_date', true))) {
        $url = get_permalink($product->get_id());
        $button = '<a href="' . esc_url($url) . '" class="button wp-element-button">' . __('Pre-Order Now', 'woocommerce') . '</a>';
    }
    return $button;
}, 10, 2);


// Change "Add to Cart" Button Text for Pre-Orders on Single Product Page
add_filter('woocommerce_product_single_add_to_cart_text', function($text, $product) {
    if (!empty(get_post_meta($product->get_id(), 'preorder_availability_date', true))) {
        return __('Pre-Order Now', 'woocommerce'); // Change the button text
    }
    return $text;
}, 10, 2);

?>